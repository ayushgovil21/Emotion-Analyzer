#!/bin/bash
python3 gettweets.py $1
python3 knn.py