#Emotion Detection And Classification of Tweets

The term paper of this work is present [here] (Documents/term_paper.pdf). Below are the highlights of the work done + the results generated for live tweets on 28 December 2015.

![Page 2](https://github.com/mjaglan/TextSentiment.V1.a.public/blob/master/Documents/images/2.PNG)
***
![Page 3](https://github.com/mjaglan/TextSentiment.V1.a.public/blob/master/Documents/images/3.PNG)
***
![Page 4](https://github.com/mjaglan/TextSentiment.V1.a.public/blob/master/Documents/images/4.PNG)
***
![Page 5](https://github.com/mjaglan/TextSentiment.V1.a.public/blob/master/Documents/images/5.PNG)
***
![Page 6](https://github.com/mjaglan/TextSentiment.V1.a.public/blob/master/Documents/images/6.png)
***
